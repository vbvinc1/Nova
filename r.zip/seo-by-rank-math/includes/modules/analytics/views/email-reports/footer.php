<?php
/**
 * Analytics Report email template footer.
 *
 * @package    RankMath
 * @subpackage RankMath\Admin
 */

defined( 'ABSPATH' ) || exit;

?>
											</td>
										</tr>
									</table>
								</td>
							</tr>

							<!-- START FOOTER -->
							<tr class="footer">
								<td class="wrapper">
									<p class="first">
										###FOOTER_HTML###
									</p>
								</td>
							</tr>
							<!-- END FOOTER -->

							<!-- END MAIN CONTENT AREA -->

						</table>
						<!-- END CENTERED WHITE CONTAINER -->

					</div>
				</td>
				<td>&nbsp;</td>
			</tr>
		</table>
	</body>
</html>
