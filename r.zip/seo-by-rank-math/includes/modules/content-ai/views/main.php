<?php
/**
 * Content AI Page main view.
 *
 * @package RankMath
 * @subpackage RankMath\Role_Manager
 */

defined( 'ABSPATH' ) || exit;
?>
<div id="rank-math-content-ai-page">
	<div class="rank-math-box container">
	</div>
</div>
